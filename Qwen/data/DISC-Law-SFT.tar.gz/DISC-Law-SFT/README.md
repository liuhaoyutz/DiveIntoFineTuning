---
license: Apache License 2.0
text:
  zero-shot:
    language:
      - zh
  conversational:
    size_scale:
      - ">1m"
    type:
      - task-qa
  text-generation:
    language:
      - zh
    type:
      - question-generation
  summarization:
    size_scale:
      - ">1m"
  question-answering:
    language:
      - zh
tags:
- modelscope-agent
- llm-plugins
- api bench
- tool learning

---

# DISC-Law-SFT Dataset

Legal Intelligent systems in Chinese require a combination of various abilities, including legal text understanding and generation. To achieve this, we have constructed a high-quality supervised fine-tuning dataset called DISC-Law-SFT, which covers different legal scenarios such as legal information extraction, legal judgment prediction, legal document summarization, and legal question answering. DISC-Law-SFT comprises two subsets, DISC-Law-SFT-Pair and DISC-Law-SFT-Triplet. The former aims to introduce legal reasoning abilities to the LLM, while the latter helps enhance the model's capability to utilize external legal knowledge. For more detailed information, please refer to our [technical report](https://arxiv.org/abs/2309.11325). The distribution of the dataset is:


We currently open-source most of the DISC-Law-SFT Dataset.

More detail and news check our [homepage](https://github.com/FudanDISC/DISC-LawLLM) !
